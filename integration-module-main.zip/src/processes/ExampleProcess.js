import { makeId } from '#src/utils/ids.js'
import { success, failure } from '#src/utils/response.js'
import Process from './Process.js'
import { getProfileData } from '#src/controller/getdata.js'

class ExampleProcess extends Process {
  constructor() {
    super('ExampleProcess')
  }

  async run(message) {
    // this.log.info(message)
    const data = await getProfileData(message)
    console.log("data", data)
    // if (message.hasError) {
    //   return failure('ExampleProcess failed')
    // }
    // return success({ example_id: makeId('ex'), example_output: 'Output object from ExampleProcess' })
  }
}

export default ExampleProcess
