import got from 'got'


async function getProfileData(message) {
    const email = message.body.email;
    const API_ENDPOINT = "https://api.apollo.io/v1/people/match";
    const apolloKey = message.apolloKey;
    const sendData = {
        "api_key": `${apolloKey}`,
        "email": `${email}`,
        "reveal_personal_emails": true
    };
    const headers = {
        'Cache-Control': 'no-cache',
        'Content-Type': 'application/json'
    };
    console.log("sendData",sendData)
    
    try {
        const response = await got.post(API_ENDPOINT, {
            headers: headers,
            responseType: 'json',
            json: sendData,
        });
        console.log("response", response)
        
        const data = JSON.parse(response.body);
        return data
        

    } catch (error) {
        console.error(error.response);
        if (error.response && error.response.statusCode) {
            return `${error.response.statusCode} Error`;
        } else {
            return "HTTP connection error";
        }
    }
}

export { getProfileData }